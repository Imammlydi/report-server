// const mongoose = require('mongoose');

// const inspectorSchema = new mongoose.Schema({
//     name :{
//         type:String,
//         required:true
//     },
//     reportId: [{
//         type: ObjectId,
//         ref: 'Report'
//     }]
// })

// module.exports = mongoose.model('Inspector',inspectorSchema)